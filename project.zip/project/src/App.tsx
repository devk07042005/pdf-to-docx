import React from 'react';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Hero } from './components/Hero';
import { FileUpload } from './components/FileUpload';
import { ConversionStats } from './components/ConversionStats';
import { ConversionProgress } from './components/ConversionProgress';
import { FAQ } from './components/FAQ';
import { Footer } from './components/Footer';
import { useFileConverter } from './hooks/useFileConverter';

function App() {
  const {
    files,
    isConverting,
    stats,
    addFiles,
    removeFile,
    clearCompleted,
    retryFile,
  } = useFileConverter();

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gray-50">
        <Hero />
        
        <main className="py-16 space-y-16">
          <section className="px-4 sm:px-6 lg:px-8">
            <FileUpload
              onFilesSelected={addFiles}
              maxFiles={3}
              currentFileCount={files.length}
            />
          </section>

          {files.length > 0 && (
            <section className="px-4 sm:px-6 lg:px-8">
              <ConversionStats
                stats={stats}
                onClearCompleted={clearCompleted}
              />
              
              <ConversionProgress
                files={files}
                onRemove={removeFile}
                onRetry={retryFile}
              />
            </section>
          )}
        </main>

        <FAQ />
        <Footer />
      </div>
    </ErrorBoundary>
  );
}

export default App;