import React, { useCallback, useState } from 'react';
import { Upload, FileText, X, AlertCircle } from 'lucide-react';

interface FileUploadProps {
  onFilesSelected: (files: File[]) => void;
  maxFiles: number;
  currentFileCount: number;
}

export const FileUpload: React.FC<FileUploadProps> = ({ 
  onFilesSelected, 
  maxFiles, 
  currentFileCount 
}) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [dragCounter, setDragCounter] = useState(0);

  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragCounter(prev => prev + 1);
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      setIsDragOver(true);
    }
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragCounter(prev => prev - 1);
    if (dragCounter <= 1) {
      setIsDragOver(false);
    }
  }, [dragCounter]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    setDragCounter(0);
    
    const files = Array.from(e.dataTransfer.files);
    const availableSlots = maxFiles - currentFileCount;
    const filesToAdd = files.slice(0, availableSlots);
    
    if (filesToAdd.length > 0) {
      onFilesSelected(filesToAdd);
    }
  }, [onFilesSelected, maxFiles, currentFileCount]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      const availableSlots = maxFiles - currentFileCount;
      const filesToAdd = files.slice(0, availableSlots);
      
      if (filesToAdd.length > 0) {
        onFilesSelected(filesToAdd);
      }
      e.target.value = '';
    }
  }, [onFilesSelected, maxFiles, currentFileCount]);

  const canAcceptFiles = currentFileCount < maxFiles;

  return (
    <div className="max-w-4xl mx-auto">
      <div
        className={`
          relative border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-300
          ${isDragOver && canAcceptFiles
            ? 'border-blue-500 bg-blue-50 scale-105' 
            : canAcceptFiles
            ? 'border-gray-300 hover:border-blue-400 hover:bg-blue-50/50'
            : 'border-gray-200 bg-gray-50 cursor-not-allowed opacity-60'
          }
        `}
        onDragEnter={handleDragEnter}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {!canAcceptFiles && (
          <div className="absolute top-4 right-4 flex items-center gap-2 bg-amber-100 text-amber-800 px-3 py-1 rounded-lg text-sm">
            <AlertCircle className="w-4 h-4" />
            Maximum {maxFiles} files reached
          </div>
        )}

        <div className="mb-6">
          <div className={`
            inline-flex items-center justify-center w-20 h-20 rounded-full mb-4 transition-all duration-300
            ${isDragOver && canAcceptFiles
              ? 'bg-blue-100 text-blue-600 scale-110' 
              : 'bg-gray-100 text-gray-400'
            }
          `}>
            <Upload className="w-10 h-10" />
          </div>
        </div>

        <h3 className="text-xl font-semibold text-gray-900 mb-2">
          {canAcceptFiles ? 'Drop your PDF files here' : 'Upload limit reached'}
        </h3>
        
        <p className="text-gray-600 mb-6">
          {canAcceptFiles 
            ? `or click to browse • Up to ${maxFiles - currentFileCount} more files • Max 25MB each`
            : 'Remove some files to upload more'
          }
        </p>

        {canAcceptFiles && (
          <>
            <input
              type="file"
              accept=".pdf"
              multiple
              onChange={handleFileSelect}
              className="hidden"
              id="file-upload"
              disabled={!canAcceptFiles}
            />
            <label
              htmlFor="file-upload"
              className="inline-flex items-center gap-2 bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer font-medium"
            >
              <FileText className="w-5 h-5" />
              Choose PDF Files
            </label>
          </>
        )}

        <div className="mt-8 flex items-center justify-center gap-6 text-sm text-gray-500">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span>Secure Upload</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
            <span>Fast Processing</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
            <span>High Quality</span>
          </div>
        </div>
      </div>
    </div>
  );
};