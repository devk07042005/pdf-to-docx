import React from 'react';
import { FileText, Download, Zap, Shield, Clock, Users } from 'lucide-react';

export const Hero: React.FC = () => {
  const features = [
    {
      icon: Zap,
      title: 'Lightning Fast',
      description: 'Convert files in seconds with our optimized processing engine'
    },
    {
      icon: Shield,
      title: 'Secure & Private',
      description: 'Your files are processed securely and deleted after conversion'
    },
    {
      icon: Clock,
      title: 'No Time Limits',
      description: 'Convert as many files as you need without restrictions'
    },
    {
      icon: Users,
      title: 'Batch Processing',
      description: 'Convert up to 3 files simultaneously for efficiency'
    }
  ];

  return (
    <div className="bg-gradient-to-br from-blue-600 via-purple-600 to-blue-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="p-3 bg-white/10 backdrop-blur-sm rounded-2xl">
              <FileText className="w-8 h-8" />
            </div>
            <h1 className="text-5xl lg:text-6xl font-bold">
              PDF to DOCX
              <span className="block text-3xl lg:text-4xl font-normal text-blue-100 mt-2">
                Converter
              </span>
            </h1>
          </div>
          
          <p className="text-xl lg:text-2xl text-blue-100 mb-8 max-w-3xl mx-auto leading-relaxed">
            Transform your PDF documents into editable DOCX files instantly. 
            Professional-grade conversion with perfect formatting preservation.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <div className="flex items-center gap-2 text-blue-100">
              <Download className="w-5 h-5" />
              <span>Free Forever</span>
            </div>
            <div className="hidden sm:block w-1 h-1 bg-blue-300 rounded-full"></div>
            <div className="flex items-center gap-2 text-blue-100">
              <Shield className="w-5 h-5" />
              <span>No Registration Required</span>
            </div>
            <div className="hidden sm:block w-1 h-1 bg-blue-300 rounded-full"></div>
            <div className="flex items-center gap-2 text-blue-100">
              <Zap className="w-5 h-5" />
              <span>Instant Processing</span>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/15 transition-all duration-300 hover:transform hover:scale-105"
            >
              <div className="mb-4">
                <feature.icon className="w-8 h-8 text-blue-200" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
              <p className="text-blue-100 text-sm leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};