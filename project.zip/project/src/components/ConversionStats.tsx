import React from 'react';
import { BarChart3, CheckCircle, XCircle, Clock } from 'lucide-react';
import { ConversionStats as StatsType } from '../types';

interface ConversionStatsProps {
  stats: StatsType;
  onClearCompleted: () => void;
}

export const ConversionStats: React.FC<ConversionStatsProps> = ({
  stats,
  onClearCompleted
}) => {
  if (stats.totalFiles === 0) return null;

  const pendingFiles = stats.totalFiles - stats.completedFiles - stats.failedFiles;
  const successRate = stats.totalFiles > 0 ? Math.round((stats.completedFiles / stats.totalFiles) * 100) : 0;

  return (
    <div className="max-w-4xl mx-auto mb-8">
      <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-50 rounded-lg">
              <BarChart3 className="w-5 h-5 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">
              Conversion Dashboard
            </h3>
          </div>

          {stats.completedFiles > 0 && (
            <button
              onClick={onClearCompleted}
              className="text-sm text-gray-600 hover:text-gray-800 transition-colors"
            >
              Clear Completed
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">{stats.totalFiles}</div>
            <div className="text-sm text-gray-600">Total Files</div>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center gap-1">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <div className="text-2xl font-bold text-green-600">{stats.completedFiles}</div>
            </div>
            <div className="text-sm text-gray-600">Completed</div>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center gap-1">
              <Clock className="w-4 h-4 text-amber-500" />
              <div className="text-2xl font-bold text-amber-600">{pendingFiles}</div>
            </div>
            <div className="text-sm text-gray-600">Processing</div>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center gap-1">
              <XCircle className="w-4 h-4 text-red-500" />
              <div className="text-2xl font-bold text-red-600">{stats.failedFiles}</div>
            </div>
            <div className="text-sm text-gray-600">Failed</div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Success Rate</span>
            <span className="font-medium text-gray-900">{successRate}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-green-500 h-2 rounded-full transition-all duration-500"
              style={{ width: `${successRate}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};