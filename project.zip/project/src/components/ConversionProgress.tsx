import React from 'react';
import { FileText, Download, Trash2, RotateCcw, CheckCircle, XCircle, Clock } from 'lucide-react';
import { ConversionFile } from '../types';

interface ConversionProgressProps {
  files: ConversionFile[];
  onRemove: (fileId: string) => void;
  onRetry: (fileId: string) => void;
}

export const ConversionProgress: React.FC<ConversionProgressProps> = ({
  files,
  onRemove,
  onRetry
}) => {
  if (files.length === 0) return null;

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const getStatusIcon = (status: ConversionFile['status']) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-5 h-5 text-amber-500" />;
      case 'converting':
        return <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />;
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'error':
        return <XCircle className="w-5 h-5 text-red-500" />;
    }
  };

  const getStatusText = (file: ConversionFile): string => {
    switch (file.status) {
      case 'pending':
        return 'Waiting in queue...';
      case 'converting':
        return `Converting... ${file.progress}%`;
      case 'completed':
        return 'Ready for download';
      case 'error':
        return file.error || 'Conversion failed';
    }
  };

  const handleDownload = (file: ConversionFile) => {
    if (file.downloadUrl) {
      // In a real implementation, this would trigger an actual download
      const link = document.createElement('a');
      link.href = '#';
      link.download = file.file.name.replace('.pdf', '.docx');
      link.click();
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-2">
          Conversion Progress
        </h3>
        <p className="text-gray-600">
          Track the status of your file conversions
        </p>
      </div>

      <div className="space-y-4">
        {files.map((file) => (
          <div
            key={file.id}
            className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-red-50 rounded-lg flex items-center justify-center">
                  <FileText className="w-6 h-6 text-red-600" />
                </div>
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h4 className="text-sm font-medium text-gray-900 truncate">
                      {file.file.name}
                    </h4>
                    <p className="text-sm text-gray-500">
                      {formatFileSize(file.file.size)}
                    </p>
                  </div>
                  
                  <div className="flex items-center gap-2 ml-4">
                    {getStatusIcon(file.status)}
                    <span className="text-sm text-gray-600">
                      {getStatusText(file)}
                    </span>
                  </div>
                </div>

                {file.status === 'converting' && (
                  <div className="mb-3">
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300 ease-out"
                        style={{ width: `${file.progress}%` }}
                      />
                    </div>
                  </div>
                )}

                {file.error && (
                  <div className="mb-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                    <p className="text-sm text-red-700">{file.error}</p>
                  </div>
                )}

                <div className="flex items-center gap-2">
                  {file.status === 'completed' && (
                    <button
                      onClick={() => handleDownload(file)}
                      className="inline-flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm font-medium"
                    >
                      <Download className="w-4 h-4" />
                      Download DOCX
                    </button>
                  )}

                  {file.status === 'error' && (
                    <button
                      onClick={() => onRetry(file.id)}
                      className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                    >
                      <RotateCcw className="w-4 h-4" />
                      Retry
                    </button>
                  )}

                  <button
                    onClick={() => onRemove(file.id)}
                    className="inline-flex items-center gap-2 bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors text-sm font-medium"
                  >
                    <Trash2 className="w-4 h-4" />
                    Remove
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};