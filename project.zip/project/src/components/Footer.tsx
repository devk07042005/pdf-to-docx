import React from 'react';
import { FileText, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 mb-4">
            <div className="p-2 bg-blue-600 rounded-lg">
              <FileText className="w-5 h-5" />
            </div>
            <span className="text-xl font-bold">PDF to DOCX Converter</span>
          </div>
          
          <p className="text-gray-400 mb-6 max-w-2xl mx-auto">
            The fastest and most reliable way to convert your PDF documents to editable DOCX format. 
            Trusted by thousands of users worldwide for professional document conversion.
          </p>
          
          <div className="flex items-center justify-center gap-1 text-gray-400">
            <span>Made with</span>
            <Heart className="w-4 h-4 text-red-500 fill-current" />
            <span>for better document workflows</span>
          </div>
          
          <div className="mt-6 pt-6 border-t border-gray-800">
            <p className="text-sm text-gray-500">
              © 2025 PDF to DOCX Converter. Your privacy is our priority.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};