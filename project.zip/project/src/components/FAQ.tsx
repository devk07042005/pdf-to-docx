import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

export const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: "Is my data secure when converting files?",
      answer: "Yes, absolutely. All files are processed securely in your browser and are automatically deleted after conversion. We never store your documents on our servers, ensuring complete privacy and security."
    },
    {
      question: "What file formats are supported?",
      answer: "Currently, we support converting PDF files to DOCX format. The converted DOCX files maintain the original formatting, layout, and content structure as closely as possible."
    },
    {
      question: "Is there a file size limit?",
      answer: "Yes, individual files must be under 25MB for optimal processing speed and quality. For larger files, consider compressing the PDF before conversion or splitting it into smaller documents."
    },
    {
      question: "How many files can I convert at once?",
      answer: "You can convert up to 3 files simultaneously. This batch processing feature helps you save time while ensuring each conversion receives adequate processing resources for the best quality."
    },
    {
      question: "Do I need to create an account?",
      answer: "No account required! Our converter works completely anonymously. Simply upload your PDF files and download the converted DOCX files - it's that simple."
    },
    {
      question: "How long does the conversion process take?",
      answer: "Most conversions complete within 30-60 seconds, depending on the file size and complexity. Simple text documents convert faster than image-heavy PDFs with complex formatting."
    },
    {
      question: "Will the formatting be preserved?",
      answer: "Our advanced conversion engine preserves text formatting, fonts, images, tables, and layout structure. While most elements transfer perfectly, complex layouts may require minor adjustments."
    },
    {
      question: "Can I convert password-protected PDFs?",
      answer: "Currently, password-protected PDFs are not supported. You'll need to remove the password protection from your PDF before uploading it for conversion."
    }
  ];

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="bg-gray-50 py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 mb-4">
            <HelpCircle className="w-6 h-6 text-blue-600" />
            <h2 className="text-3xl font-bold text-gray-900">
              Frequently Asked Questions
            </h2>
          </div>
          <p className="text-lg text-gray-600">
            Everything you need to know about our PDF to DOCX converter
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden"
            >
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <h3 className="text-lg font-medium text-gray-900 pr-4">
                  {faq.question}
                </h3>
                <ChevronDown
                  className={`w-5 h-5 text-gray-500 transition-transform duration-200 flex-shrink-0 ${
                    openIndex === index ? 'transform rotate-180' : ''
                  }`}
                />
              </button>
              
              {openIndex === index && (
                <div className="px-6 pb-4">
                  <div className="border-t border-gray-100 pt-4">
                    <p className="text-gray-600 leading-relaxed">
                      {faq.answer}
                    </p>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};