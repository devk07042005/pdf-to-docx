export interface ConversionFile {
  id: string;
  file: File;
  status: 'pending' | 'converting' | 'completed' | 'error';
  progress: number;
  downloadUrl?: string;
  error?: string;
  convertedAt?: Date;
}

export interface ConversionStats {
  totalFiles: number;
  completedFiles: number;
  failedFiles: number;
}