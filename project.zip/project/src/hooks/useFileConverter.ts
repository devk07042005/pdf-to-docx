import { useState, useCallback } from 'react';
import { ConversionFile, ConversionStats } from '../types';

export const useFileConverter = () => {
  const [files, setFiles] = useState<ConversionFile[]>([]);
  const [isConverting, setIsConverting] = useState(false);

  const validateFile = (file: File): string | null => {
    if (file.type !== 'application/pdf') {
      return 'Only PDF files are supported';
    }
    if (file.size > 25 * 1024 * 1024) {
      return 'File size must be less than 25MB';
    }
    return null;
  };

  const simulateConversion = async (fileId: string): Promise<void> => {
    return new Promise((resolve) => {
      const updateProgress = (progress: number) => {
        setFiles(prev => 
          prev.map(f => 
            f.id === fileId 
              ? { ...f, progress, status: progress === 100 ? 'completed' : 'converting' as const }
              : f
          )
        );
      };

      // Simulate realistic conversion progress
      let progress = 0;
      const interval = setInterval(() => {
        progress += Math.random() * 15 + 5;
        if (progress >= 100) {
          progress = 100;
          clearInterval(interval);
          
          // Simulate download URL generation
          setFiles(prev => 
            prev.map(f => 
              f.id === fileId 
                ? { 
                    ...f, 
                    progress: 100, 
                    status: 'completed',
                    downloadUrl: `#download-${fileId}`,
                    convertedAt: new Date()
                  }
                : f
            )
          );
          resolve();
        } else {
          updateProgress(Math.round(progress));
        }
      }, 200 + Math.random() * 300);
    });
  };

  const addFiles = useCallback(async (newFiles: File[]) => {
    const validatedFiles: ConversionFile[] = [];
    
    for (const file of newFiles) {
      const error = validateFile(file);
      const conversionFile: ConversionFile = {
        id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        file,
        status: error ? 'error' : 'pending',
        progress: 0,
        error
      };
      validatedFiles.push(conversionFile);
    }

    setFiles(prev => [...prev, ...validatedFiles]);

    // Start conversion for valid files
    const validFiles = validatedFiles.filter(f => !f.error);
    if (validFiles.length > 0) {
      setIsConverting(true);
      
      // Convert files sequentially to avoid overwhelming the system
      for (const file of validFiles) {
        await simulateConversion(file.id);
      }
      
      setIsConverting(false);
    }
  }, []);

  const removeFile = useCallback((fileId: string) => {
    setFiles(prev => prev.filter(f => f.id !== fileId));
  }, []);

  const clearCompleted = useCallback(() => {
    setFiles(prev => prev.filter(f => f.status !== 'completed'));
  }, []);

  const retryFile = useCallback(async (fileId: string) => {
    setFiles(prev => 
      prev.map(f => 
        f.id === fileId 
          ? { ...f, status: 'pending', progress: 0, error: undefined }
          : f
      )
    );

    setIsConverting(true);
    await simulateConversion(fileId);
    setIsConverting(false);
  }, []);

  const stats: ConversionStats = {
    totalFiles: files.length,
    completedFiles: files.filter(f => f.status === 'completed').length,
    failedFiles: files.filter(f => f.status === 'error').length,
  };

  return {
    files,
    isConverting,
    stats,
    addFiles,
    removeFile,
    clearCompleted,
    retryFile,
  };
};